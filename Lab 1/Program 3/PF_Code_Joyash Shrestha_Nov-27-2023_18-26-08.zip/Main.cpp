/* Sample C++ code */
#include <iostream>
#define pi 3.14
using namespace std;
int main() {
    int r;
    float a,p;
    cout << "Enter radius:";
    cin >>r;
    p=2*pi*r;
    a=pi*r*r;
    cout << "\nPerimeter is "<<p;
    cout <<"\nArea is "<<a;
    return 0;
};