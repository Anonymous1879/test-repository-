/* Sample C++ code */
#include <iostream>
#include <math.h>
using namespace std;
int main() {
    int x1,y1,x2,y2;
    float d;
    cout << "Enter first point:\n";
    cin >>x1>>y1;
    cout << "Enter second point:\n";
    cin >>x2>>y2;
    d=sqrt((pow((y2-y2),2))+(pow((x2-x1),2)));
    cout << "The distance is "<<d;
    return 0;
};