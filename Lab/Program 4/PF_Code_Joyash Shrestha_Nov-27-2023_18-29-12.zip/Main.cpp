/* Sample C++ code */
#include <iostream>
using namespace std;
int main() {
    int a,b;

    cout << "Enter two numbers :";
    cin >> a >>b;
    cout << "\n";
    if(a>b)
        cout <<a <<" is the greatest";
    else if(b>a)
        cout <<b <<" is the greatest";
    else 
        cout << "both are equal";
    return 0;
};